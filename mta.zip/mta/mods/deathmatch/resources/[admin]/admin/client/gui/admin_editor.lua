﻿--[[**********************************
*
*	Multi Theft Auto - Admin Panel
*
*	gui\admin_editor.lua
*
*	Original File by lil_Toady
*
**************************************]]

function nothing ()

end